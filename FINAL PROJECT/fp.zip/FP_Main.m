%% final project main
% BR and KO
clear all;
close all;
clc;


%% global variables

global bitmap

global bitmaplaser

global W gamma_max L M K D X_first_tree Y_first_tree

global dt DT


%% add path
addpath '/Users/benoitrouchy/Downloads/EBS 221 Agri Robots/MATLAB CODE'
addpath '/Users/benoitrouchy/Downloads/EBS 221 Agri Robots/MATLAB CODE/geom2d'
%% variables
% gen nursery variables
X_first_tree = 20;
Y_first_tree = 20;
R = 5000; C = 5000; %numbers of rows and columns of bitmap
K = 5; % number of tree rows running south-north direction
M = 7; %maximum number of trees in each row
W = 3; % distance between tree rows (m)
D = 2; %distance between trees in the same row (m)
bitmap = zeros(R, C); %initialize as empty
[ Xmax, Ymax, x, y] = generateNurseryFunction(X_first_tree,Y_first_tree, M, K, D,W, R,C);


%%
% robot variables
gamma_max = deg2rad(55);
L = 3;
Qmin = [-inf,-inf,-inf,-gamma_max,-2]';
Qmax = -Qmin;
tau_gamma = 0.1;
tau_v = 0.1;
Q0 = [15;15;pi/2;0;0];
Qend = [0;0;0;0;0]; %[0;40;pi/2];
Umin = [Qmin(4),Qmin(5)]';
Umax = -Umin;
vD = 1; % speed of robot
U0 = [0;0];%[0;1];
U = U0;
Rmin = L/tan(gamma_max);
Ld = 0.2*Rmin;

% laser variables
angleSpan = deg2rad(180);
angleStep = deg2rad(0.125);%angleSpan/720;%
rangeMax = 20;%20;
bitmaplaser = 0.5* ones(R, C); %initialize as unknown-occupancy pixels

% sim variables

dt = 0.01;
DT = 0.1;
timeToRun = 300;
numTimesteps = timeToRun/DT;
integrationStepsPerTimeStep = DT/dt;
numIntegrationSteps = round(numTimesteps*integrationStepsPerTimeStep);





%% path gen

[desiredPath] = OptPathGen(Q0,Qend);
x_path = desiredPath(1,:);
y_path = desiredPath(2,:);

%%



t = cputime;
crossTrackErrorMat = zeros(numTimesteps,2);
Q=Q0;
for j = 1:numTimesteps
    [gammaD,endDistance,crossTrackError,crossTrackErrorInterpolated] = purePursuit(Q,L,Ld,desiredPath);
    crossTrackErrorMat(j,1)=crossTrackError;
    crossTrackErrorMat(j,2)=crossTrackErrorInterpolated;
    if j>numTimesteps/10 && endDistance<0.35
        QAll = QAll(1:(j-1)*integrationStepsPerTimeStep,:);
        crossTrackErrorMat=crossTrackErrorMat(1:j,:);
        break
    end
    U = [gammaD;vD];%[gammaD;1];
    [QNext] = robot_bike_dyn(Q,U,Umin,Umax,Qmin,Qmax,L,tau_gamma,tau_v);
    Q = QNext(end,:)';

    % laser scan and update scan map
    if rem(j,1) ==0  % only scans some of the time
        % this speeds up the code at the expense of resolution
        Tl = SE2([Q(1),Ymax-Q(2),-Q(3)]);     % lateral motion along the x-axis
        p = laserScannerNoisy(angleSpan, angleStep, rangeMax, Tl.T, bitmap, Xmax, Ymax);
        filteredRange = medfilt1(p(:,2),5,'omitnan','truncate');
        for i=1:length(p)
            angle = p(i,1);
            % range = p(i,2);
            range = filteredRange(i,1);
            % possible infinite range is handled inside the update function
            n = updateLaserBeamGrid(angle, range, Tl.T, R, C, Xmax, Ymax);
        end
    end
    QAll((j-1)*integrationStepsPerTimeStep+1:(j-1)*integrationStepsPerTimeStep+integrationStepsPerTimeStep,:) = QNext;
    % ends loop if runs for too long
    E = cputime-t;
    if E > 60*10
        break
    end
end
E = cputime-t

%%

figure(1);
clf
hold on
imagesc([0 Xmax], [0 Ymax],bitmaplaser./(1+bitmaplaser)); title('Binary occupancy grid')
colorbar
scatter(x,y,'xr')
plot(x_path,y_path)
plot(QAll(:,1),QAll(:,2))

%%
figure(2);
clf
hold on
imagesc([0 Xmax], [0 Ymax], bitmap); %imagesc flips the bitmap rows, so correct this
set(gca,'YDir','normal');
colorbar
axis equal
scatter(x,y,'xr')